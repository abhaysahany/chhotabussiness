<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\SessionController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// Central Session Expiry & Activity Management
Route::post('/session/ping', [SessionController::class, 'ping']);
Route::get('/session/config', [SessionController::class, 'config']);

// Health & Database Connection Status Check
Route::get('/status', function () {
    $dbName = null;
    $connected = false;
    $dbStatus = "Database connection unavailable. Please check system logs.";

    try {
        $pdo = DB::connection()->getPdo();
        $dbName = DB::connection()->getDatabaseName();
        $dbStatus = "Connected to database [{$dbName}] successfully!";
        $connected = true;
    } catch (\Throwable $e) {
        \Illuminate\Support\Facades\Log::error("Database connection check failed: " . $e->getMessage());
    }

    $appName = config('app.name', 'Vyapar AdNET');
    if ($connected) {
        try {
            $appName = \App\Models\SystemSetting::get('app_name', $appName) ?: $appName;
        } catch (\Throwable $e) {
            // Keep default appName
        }
    }

    return response()->json([
        'status' => $connected ? 'success' : 'degraded',
        'app_name' => $appName ?: 'Vyapar AdNET',
        'environment' => config('app.env'),
        'database_status' => $dbStatus,
        'database_connected' => $connected,
        'database_name' => $dbName ?? 'N/A',
        'timestamp' => now()->toIso8601String(),
    ], $connected ? 200 : 503);
});

// Admin Panel API Endpoint
Route::get('/admin/info', function () {
    $appName = \App\Models\SystemSetting::get('app_name', config('app.name', 'AddNet')) ?: 'AddNet';
    return response()->json([
        'panel' => 'Admin Panel',
        'message' => "Welcome to {$appName} Admin Backend API",
        'stats' => [
            'total_users' => 128,
            'active_orders' => 42,
            'revenue_today' => '$2,450',
            'server_health' => 'Optimal',
        ],
        'features' => ['User Management', 'Analytics', 'System Settings', 'Database Logs'],
    ]);
});

use App\Http\Controllers\UserDashboardController;

// User Panel API Endpoints
Route::get('/user/info', function () {
    $appName = \App\Models\SystemSetting::get('app_name', config('app.name', 'AddNet')) ?: 'AddNet';
    return response()->json([
        'panel' => 'User Panel',
        'message' => "Welcome to {$appName} Customer Portal API",
        'services' => [
            'Business Setup',
            'GST Registration',
            'Accounting & Bookkeeping',
            'Tax Filing',
        ],
        'support_email' => 'support@addnet.com',
    ]);
});
Route::get('/user/dashboard-stats', [UserDashboardController::class, 'getDashboardStats']);
Route::get('/user/dashboard/stats', [UserDashboardController::class, 'getDashboardStats']);


use App\Http\Controllers\AuthController;
use App\Http\Controllers\UserProfileController;
use App\Http\Controllers\Admin\AdminAuthController;
use App\Http\Controllers\Admin\AdminSupportController;
use App\Http\Controllers\Admin\EntityCategoryController;
use App\Http\Controllers\Admin\BusinessEntityController;
use App\Http\Controllers\Admin\FreelancerEntityController;
use App\Http\Controllers\Admin\CommissionSettingController;

// Admin Auth Routes
Route::post('/admin/login', [AdminAuthController::class, 'login']);
Route::post('/admin/forgot-password', [AdminAuthController::class, 'forgotPassword']);
Route::post('/admin/verify-otp', [AdminAuthController::class, 'verifyOtp']);
Route::post('/admin/reset-password', [AdminAuthController::class, 'resetPassword']);

// Public Support Ticket Submission
Route::post('/support/tickets', [AdminSupportController::class, 'store']);
Route::get('/admin/support/tickets', [AdminSupportController::class, 'index']);
Route::get('/admin/support/tickets/{id}', [AdminSupportController::class, 'show']);
Route::post('/admin/support/tickets/{id}/reply', [AdminSupportController::class, 'reply']);
Route::put('/admin/support/tickets/{id}/status', [AdminSupportController::class, 'updateStatus']);

// Business Entity Admin Management Routes
Route::prefix('admin')->group(function () {
    // 1. Entity Categories
    Route::get('/entity-categories', [EntityCategoryController::class, 'index']);
    Route::post('/entity-categories', [EntityCategoryController::class, 'store']);
    Route::get('/entity-categories/{id}', [EntityCategoryController::class, 'show']);
    Route::put('/entity-categories/{id}', [EntityCategoryController::class, 'update']);
    Route::delete('/entity-categories/{id}', [EntityCategoryController::class, 'destroy']);

    // 2. Business Entity Registrations
    Route::get('/business-entities', [BusinessEntityController::class, 'index']);
    Route::post('/business-entities', [BusinessEntityController::class, 'store']);
    Route::get('/business-entities/{id}', [BusinessEntityController::class, 'show']);
    Route::put('/business-entities/{id}', [BusinessEntityController::class, 'update']);
    Route::put('/business-entities/{id}/status', [BusinessEntityController::class, 'updateStatus']);
    Route::delete('/business-entities/{id}', [BusinessEntityController::class, 'destroy']);

    // 3. Freelancer Entity Registrations
    Route::get('/freelancers', [FreelancerEntityController::class, 'index']);
    Route::post('/freelancers', [FreelancerEntityController::class, 'store']);
    Route::get('/freelancers/{id}', [FreelancerEntityController::class, 'show']);
    Route::put('/freelancers/{id}', [FreelancerEntityController::class, 'update']);
    Route::put('/freelancers/{id}/status', [FreelancerEntityController::class, 'updateStatus']);
    Route::delete('/freelancers/{id}', [FreelancerEntityController::class, 'destroy']);
});

// Public Showcase & Advertisement Endpoints for Users
Route::get('/public/categories', [EntityCategoryController::class, 'index']);
Route::get('/public/businesses', [BusinessEntityController::class, 'index']);
Route::get('/public/freelancers', [FreelancerEntityController::class, 'index']);

// Media & Marketing Content Asset Management API Endpoints (MySQL Database Backed)
use App\Http\Controllers\ContentAssetController;
use App\Http\Controllers\SupportTopicController;

Route::get('/content-assets', [ContentAssetController::class, 'index']);
Route::get('/public/content-assets', [ContentAssetController::class, 'index']);
Route::get('/admin/content-assets', [ContentAssetController::class, 'indexAdmin']);
Route::post('/admin/content-assets', [ContentAssetController::class, 'store']);
Route::post('/content-assets', [ContentAssetController::class, 'store']);
Route::put('/admin/content-assets/{id}', [ContentAssetController::class, 'update']);
Route::delete('/admin/content-assets/{id}', [ContentAssetController::class, 'destroy']);
Route::post('/content-assets/{id}/download', [ContentAssetController::class, 'trackDownload']);
Route::get('/content-assets/{id}/download-file', [ContentAssetController::class, 'downloadFile']);
Route::post('/content-assets/{id}/share', [ContentAssetController::class, 'trackShare']);

// Support Videos & Help Articles Management Endpoints (MySQL Database Backed)
Route::get('/support-topics', [SupportTopicController::class, 'index']);
Route::get('/public/support-topics', [SupportTopicController::class, 'index']);
Route::post('/public/support-topics/{id}/view', [SupportTopicController::class, 'incrementView']);
Route::post('/public/support-topics/{id}/helpful', [SupportTopicController::class, 'voteHelpful']);
Route::get('/admin/support-topics', [SupportTopicController::class, 'indexAdmin']);
Route::post('/admin/support-topics', [SupportTopicController::class, 'store']);
Route::get('/admin/support-topics/{id}', [SupportTopicController::class, 'show']);
Route::put('/admin/support-topics/{id}', [SupportTopicController::class, 'update']);
Route::put('/admin/support-topics/{id}/status', [SupportTopicController::class, 'updateStatus']);
Route::delete('/admin/support-topics/{id}', [SupportTopicController::class, 'destroy']);

// Member Network & Genealogy Endpoints (MySQL Database Backed)
use App\Http\Controllers\NetworkController;

Route::get('/user/network/direct', [NetworkController::class, 'getDirectConnections']);
Route::get('/user/network/team', [NetworkController::class, 'getTeamConnections']);
Route::get('/user/network/genealogy', [NetworkController::class, 'getGenealogyTree']);



// Public Auth & Member Verification Routes
Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);
Route::post('/auth/google', [AuthController::class, 'googleAuth']);
Route::post('/auth/social-login', [AuthController::class, 'socialLogin']);
Route::post('/verify-sponsor', [AuthController::class, 'verifySponsor']);
Route::match(['get', 'post'], '/verify-member', [AuthController::class, 'verifyMember']);
Route::post('/send-otp', [AuthController::class, 'sendOtp']);
Route::post('/verify-otp', [AuthController::class, 'verifyOtp']);
Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
Route::post('/verify-reset-otp', [AuthController::class, 'verifyResetOtp']);
Route::post('/reset-password', [AuthController::class, 'resetPassword']);
Route::post('/user/sponsor-onboarding', [AuthController::class, 'handleSponsorOnboarding']);
Route::post('/user/complete-sponsor-onboarding', [AuthController::class, 'completeSponsorOnboarding']);
Route::post('/user/skip-sponsor-onboarding', [AuthController::class, 'skipSponsorOnboarding']);


// Entity Authentication Routes
use App\Http\Controllers\EntityAuthController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\SalesRecordController;

Route::get('/entity/selectable-entities', [EntityAuthController::class, 'getSelectableEntities']);
Route::post('/entity/login', [EntityAuthController::class, 'login']);
Route::post('/entity/logout', [EntityAuthController::class, 'logout']);
Route::get('/entity/info', [EntityAuthController::class, 'info']);
Route::post('/entity/forgot-password', [EntityAuthController::class, 'forgotPassword']);
Route::post('/entity/verify-otp', [EntityAuthController::class, 'verifyOtp']);
Route::post('/entity/reset-password', [EntityAuthController::class, 'resetPassword']);

// Central Canonical Orders & Payments Management Endpoints (MySQL Database Backed)
Route::get('/orders', [OrderController::class, 'index']);
Route::post('/orders', [OrderController::class, 'store']);
Route::get('/orders/{id}', [OrderController::class, 'show']);
Route::post('/orders/{id}/receive-balance', [OrderController::class, 'receiveBalance']);
Route::post('/orders/{id}/distribute', [OrderController::class, 'distribute']);

// Legacy Sales Route Aliases (Retained for 100% Backward Compatibility)
Route::get('/sales', [OrderController::class, 'index']);
Route::post('/sales', [OrderController::class, 'store']);
Route::get('/sales/{id}', [OrderController::class, 'show']);
Route::post('/sales/{id}/receive-balance', [OrderController::class, 'receiveBalance']);
Route::post('/sales/{id}/distribute', [OrderController::class, 'distribute']);

// Payment Receipts Ledger & Commission Distribution Endpoints
Route::get('/payments/history', [OrderController::class, 'paymentsHistory']);
Route::post('/payments/{id}/distribute', [OrderController::class, 'distributePaymentCommission']);
Route::get('/user/business-reports', [OrderController::class, 'userBusinessReports']);

// User Income Summary Endpoints (Direct Income & Level Income)
use App\Http\Controllers\UserIncomeController;
use App\Http\Controllers\DiamondRewardController;

Route::get('/user/income/direct', [UserIncomeController::class, 'getDirectIncome']);
Route::get('/user/income/levels', [UserIncomeController::class, 'getLevelIncome']);
Route::get('/user/income/summary', [UserIncomeController::class, 'getIncomeSummary']);

// User Order-Wise Direct Income System Endpoints (Phase 1)
Route::get('/user/income/direct-orders', [UserIncomeController::class, 'getOrderDirectIncomeSummaries']);
Route::get('/user/income/direct-orders/{orderId}', [UserIncomeController::class, 'getOrderDirectIncomeDetails']);
Route::get('/user/direct-income/orders', [UserIncomeController::class, 'getOrderDirectIncomeSummaries']);
Route::get('/user/direct-income/orders/{orderId}', [UserIncomeController::class, 'getOrderDirectIncomeDetails']);

// User Payouts Management Endpoints (MySQL Database Backed)
use App\Http\Controllers\UserPayoutController;
use App\Http\Controllers\RewardController;

Route::get('/admin/payouts', [UserPayoutController::class, 'index']);
Route::post('/admin/payouts/{id}/disburse', [UserPayoutController::class, 'disburse']);
Route::post('/admin/payouts/{id}/reject', [UserPayoutController::class, 'reject']);
Route::post('/admin/payouts/generate-weekly', [UserPayoutController::class, 'generateWeeklyBatch']);
Route::get('/admin/payouts/stats', [UserPayoutController::class, 'stats']);
Route::get('/user/payouts', [UserPayoutController::class, 'getUserPayouts']);
Route::post('/user/payouts/withdraw', [UserPayoutController::class, 'requestWithdrawal']);

// Rewards & Business Points Claims Endpoints (MySQL Database Backed)
Route::get('/admin/rewards', [RewardController::class, 'indexAdmin']);
Route::post('/admin/rewards', [RewardController::class, 'storeReward']);
Route::put('/admin/rewards/{id}', [RewardController::class, 'updateReward']);
Route::delete('/admin/rewards/{id}', [RewardController::class, 'destroyReward']);
Route::get('/admin/reward-claims', [RewardController::class, 'indexClaimsAdmin']);
Route::post('/admin/reward-claims/{id}/status', [RewardController::class, 'updateClaimStatus']);

// User Panel Reward Endpoints
Route::get('/user/rewards', [RewardController::class, 'indexUserRewards']);
Route::get('/user/rewards/{id}', [RewardController::class, 'showUserReward']);
Route::get('/user/reward-claims', [RewardController::class, 'indexUserClaims']);
Route::get('/user/claims', [RewardController::class, 'indexUserClaims']);
Route::post('/user/rewards/claim', [RewardController::class, 'claimReward']);

// Notification System Endpoints (Targeted & Broadcast)
use App\Http\Controllers\NotificationController;

Route::get('/admin/notifications', [NotificationController::class, 'indexAdmin']);
Route::post('/admin/notifications/send', [NotificationController::class, 'sendNotification']);
Route::get('/user/notifications', [NotificationController::class, 'indexUser']);
Route::post('/user/notifications/{id}/read', [NotificationController::class, 'markAsRead']);
Route::post('/user/notifications/read-all', [NotificationController::class, 'markAllAsRead']);

// Dedicated Admin & Entity Route Aliases
use App\Http\Controllers\AdminDashboardController;
use App\Http\Controllers\Admin\AdminUserController;

Route::get('/admin/dashboard-stats', [AdminDashboardController::class, 'getDashboardStats']);
Route::get('/admin/users', [AdminUserController::class, 'index']);
Route::put('/admin/users/{id}', [AdminUserController::class, 'update']);
Route::post('/admin/users/{id}/toggle-status', [AdminUserController::class, 'toggleStatus']);
// Admin Orders Canonical Endpoints & Legacy Sales Aliases
use App\Http\Controllers\Admin\IncomeAllocationController;

Route::get('/admin/orders', [OrderController::class, 'index']);
Route::post('/admin/orders', [OrderController::class, 'store']);
Route::post('/admin/orders/{id}/confirm', [OrderController::class, 'confirmOrder']);
Route::post('/admin/orders/{id}/cancel', [OrderController::class, 'cancelOrder']);
Route::post('/admin/orders/{id}/distribute', [OrderController::class, 'distribute']);
Route::get('/admin/orders/{orderId}/income-allocation', [IncomeAllocationController::class, 'show']);
Route::post('/admin/orders/{orderId}/income-allocation', [IncomeAllocationController::class, 'allocate']);
Route::put('/admin/orders/{orderId}/dump-amount', [IncomeAllocationController::class, 'updateDumpAmount']);
Route::post('/admin/orders/{orderId}/dump-amount', [IncomeAllocationController::class, 'updateDumpAmount']);

// Admin Payment-Level Income Allocation Endpoints
Route::get('/admin/payments/{paymentId}/income-allocation', [IncomeAllocationController::class, 'showPayment']);
Route::post('/admin/payments/{paymentId}/income-allocation', [IncomeAllocationController::class, 'allocatePayment']);

Route::get('/admin/sales', [OrderController::class, 'index']);
Route::post('/admin/sales', [OrderController::class, 'store']);
Route::post('/admin/sales/{id}/confirm', [OrderController::class, 'confirmOrder']);
Route::post('/admin/sales/{id}/cancel', [OrderController::class, 'cancelOrder']);
Route::post('/admin/sales/{id}/distribute', [OrderController::class, 'distribute']);
Route::get('/admin/sales/{orderId}/income-allocation', [IncomeAllocationController::class, 'show']);
Route::post('/admin/sales/{orderId}/income-allocation', [IncomeAllocationController::class, 'allocate']);

Route::get('/admin/payments/history', [OrderController::class, 'paymentsHistory']);
Route::get('/admin/payments/distributed-history', [OrderController::class, 'paymentsHistory']);
Route::post('/admin/payments/{id}/distribute', [OrderController::class, 'distributePaymentCommission']);

// Dump Payment Request & Approval APIs
use App\Http\Controllers\DumpPaymentController;

Route::get('/admin/dump-requests', [DumpPaymentController::class, 'getAdminDumpRequests']);
Route::get('/admin/dump-requests/{id}', [DumpPaymentController::class, 'getAdminDumpRequestDetails']);
Route::post('/admin/dump-requests/{id}/approve', [DumpPaymentController::class, 'approveDump']);
Route::post('/admin/dump-requests/{id}/reject', [DumpPaymentController::class, 'rejectDump']);

Route::post('/orders/{orderId}/report-dump', [DumpPaymentController::class, 'reportDump']);
Route::post('/sales/{orderId}/report-dump', [DumpPaymentController::class, 'reportDump']);
Route::post('/entity/orders/{orderId}/report-dump', [DumpPaymentController::class, 'reportDump']);
Route::post('/entity/sales/{orderId}/report-dump', [DumpPaymentController::class, 'reportDump']);
Route::get('/entity/dump-requests', [DumpPaymentController::class, 'getEntityDumpRequests']);
Route::get('/entity/orders/{orderId}/dump-requests', [DumpPaymentController::class, 'getEntityDumpRequests']);

use App\Http\Controllers\EntityPayoutController;
use App\Http\Controllers\EntityDashboardController;

Route::get('/entity/dashboard-stats', [EntityDashboardController::class, 'getDashboardStats']);

// Entity Orders Canonical Endpoints & Legacy Sales Aliases
Route::get('/entity/orders', [OrderController::class, 'index']);
Route::post('/entity/orders', [OrderController::class, 'store']);
Route::post('/entity/orders/{id}/receive-balance', [OrderController::class, 'receiveBalance']);
Route::get('/entity/sales', [OrderController::class, 'index']);
Route::post('/entity/sales', [OrderController::class, 'store']);
Route::post('/entity/sales/{id}/receive-balance', [OrderController::class, 'receiveBalance']);

Route::get('/entity/payments/history', [OrderController::class, 'paymentsHistory']);
Route::get('/entity/payouts', [EntityPayoutController::class, 'index']);
Route::get('/entity/payouts/reports', [EntityPayoutController::class, 'reports']);



// Products, Services & Categories MySQL Catalog Endpoints
use App\Http\Controllers\ProductCatalogController;

Route::get('/catalog/products', [ProductCatalogController::class, 'indexProducts']);
Route::post('/catalog/products', [ProductCatalogController::class, 'storeProduct']);
Route::put('/catalog/products/{id}', [ProductCatalogController::class, 'updateProduct']);
Route::delete('/catalog/products/{id}', [ProductCatalogController::class, 'destroyProduct']);

Route::get('/catalog/services', [ProductCatalogController::class, 'indexServices']);
Route::post('/catalog/services', [ProductCatalogController::class, 'storeService']);
Route::put('/catalog/services/{id}', [ProductCatalogController::class, 'updateService']);
Route::delete('/catalog/services/{id}', [ProductCatalogController::class, 'destroyService']);

Route::get('/catalog/categories', [ProductCatalogController::class, 'indexCategories']);
Route::post('/catalog/categories', [ProductCatalogController::class, 'storeCategory']);

Route::get('/catalog/packages', [ProductCatalogController::class, 'indexPackages']);
Route::post('/catalog/packages', [ProductCatalogController::class, 'storePackage']);
Route::put('/catalog/packages/{id}', [ProductCatalogController::class, 'updatePackage']);
Route::delete('/catalog/packages/{id}', [ProductCatalogController::class, 'destroyPackage']);

// System Settings Database Routes
use App\Http\Controllers\SystemSettingController;

Route::get('/settings', [SystemSettingController::class, 'getSettings']);
Route::post('/settings', [SystemSettingController::class, 'saveSettings']);
Route::get('/settings/social-links', [SystemSettingController::class, 'getSocialLinks']);
Route::post('/settings/social-links', [SystemSettingController::class, 'saveSocialLinks']);
Route::get('/branding', [SystemSettingController::class, 'getBranding']);




use App\Http\Controllers\UserBankKycController;

// User KYC (PAN & Aadhaar only)
Route::post('/user/kyc/submit', [UserBankKycController::class, 'submitKyc']);
Route::post('/user/update-kyc', [UserBankKycController::class, 'submitKyc']);

// User Multiple Bank & UPI Payout Accounts (Only accessible after KYC; requires Email OTP)
Route::get('/user/payout-accounts', [UserBankKycController::class, 'getBankAndUpiAccounts']);
Route::post('/user/send-bank-otp', [UserBankKycController::class, 'sendOtp']);
Route::post('/user/bank-accounts/add', [UserBankKycController::class, 'addBankAccount']);
Route::post('/user/bank-accounts/{id}/delete', [UserBankKycController::class, 'deleteBankAccount']);
Route::post('/user/bank-accounts/{id}/primary', [UserBankKycController::class, 'setPrimaryBankAccount']);
Route::post('/user/upi-accounts/add', [UserBankKycController::class, 'addUpiAccount']);
Route::post('/user/upi-accounts/{id}/delete', [UserBankKycController::class, 'deleteUpiAccount']);
Route::post('/user/upi-accounts/{id}/primary', [UserBankKycController::class, 'setPrimaryUpiAccount']);
// Admin KYC Compliance routes
Route::get('/admin/kyc-requests', [UserBankKycController::class, 'adminIndexKyc']);
Route::post('/admin/kyc/{id}/approve', [UserBankKycController::class, 'adminApproveKyc']);
Route::post('/admin/kyc/{id}/reject', [UserBankKycController::class, 'adminRejectKyc']);

use App\Http\Controllers\SupportTicketController;

// Support Tickets (Database Backed)
Route::get('/user/support-tickets', [SupportTicketController::class, 'getUserTickets']);
Route::post('/user/support-tickets', [SupportTicketController::class, 'createTicket']);
Route::post('/user/support-tickets/{id}/reply', [SupportTicketController::class, 'replyTicket']);
Route::post('/user/support-tickets/{id}/status', [SupportTicketController::class, 'updateStatus']);

Route::get('/admin/support-tickets', [SupportTicketController::class, 'getAdminTickets']);
Route::get('/admin/support/tickets', [SupportTicketController::class, 'getAdminTickets']);
Route::post('/admin/support-tickets/{id}/reply', [SupportTicketController::class, 'replyTicket']);
Route::post('/admin/support/tickets/{id}/reply', [SupportTicketController::class, 'replyTicket']);
Route::post('/admin/support-tickets/{id}/status', [SupportTicketController::class, 'updateStatus']);
Route::put('/admin/support/tickets/{id}/status', [SupportTicketController::class, 'updateStatus']);

// Protected Auth Routes (Sanctum)
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/me', [AuthController::class, 'me']);
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::post('/user/update-password', [AuthController::class, 'updatePassword']);

    // User Diamond Rewards Wallet & Ledger
    Route::get('/user/diamonds', [DiamondRewardController::class, 'index']);
    Route::get('/user/rewards/diamonds', [DiamondRewardController::class, 'index']);

    // User Sponsor ID Onboarding Routes
    Route::post('/user/sponsor-onboarding', [AuthController::class, 'handleSponsorOnboarding']);
    Route::post('/user/complete-sponsor-onboarding', [AuthController::class, 'completeSponsorOnboarding']);
    Route::post('/user/skip-sponsor-onboarding', [AuthController::class, 'skipSponsorOnboarding']);

    // User Profile Management & Avatar Photo Routes
    Route::get('/user/profile', [UserProfileController::class, 'getProfile']);
    Route::post('/user/profile', [UserProfileController::class, 'updateProfile']);
    Route::put('/user/profile', [UserProfileController::class, 'updateProfile']);
    Route::post('/user/profile/photo', [UserProfileController::class, 'uploadPhoto']);
    Route::post('/user/profile-photo', [UserProfileController::class, 'uploadPhoto']);
    Route::delete('/user/profile/photo', [UserProfileController::class, 'removePhoto']);
    Route::post('/user/profile/photo/remove', [UserProfileController::class, 'removePhoto']);
    
    // Protected Entity Routes
    Route::get('/entity/me', [EntityAuthController::class, 'me']);

    // Protected Admin Routes
    Route::get('/admin/me', [AdminAuthController::class, 'me']);
    Route::post('/admin/logout', [AdminAuthController::class, 'logout']);

    // Global MLM Income Commission Settings
    Route::get('/admin/commission-settings', [CommissionSettingController::class, 'index']);
    Route::post('/admin/commission-settings', [CommissionSettingController::class, 'save']);
    Route::put('/admin/commission-settings', [CommissionSettingController::class, 'save']);

    // Admin Application Branding Settings
    Route::get('/admin/branding', [SystemSettingController::class, 'getBranding']);
    Route::post('/admin/branding', [SystemSettingController::class, 'saveBranding']);
    Route::get('/admin/settings/branding', [SystemSettingController::class, 'getBranding']);
    Route::post('/admin/settings/branding', [SystemSettingController::class, 'saveBranding']);
    Route::put('/admin/settings/branding', [SystemSettingController::class, 'saveBranding']);

    // Admin Global Order-wise Direct Income Reporting Endpoints (Admin Phase 1)
    Route::prefix('admin/income')->group(function () {
        Route::get('/direct-overview', [\App\Http\Controllers\Admin\AdminIncomeReportController::class, 'getDirectIncomeOverview']);
        Route::get('/direct-orders', [\App\Http\Controllers\Admin\AdminIncomeReportController::class, 'getOrderDirectIncomeList']);
        Route::get('/direct-orders/{orderId}', [\App\Http\Controllers\Admin\AdminIncomeReportController::class, 'getOrderDirectIncomeDetails']);
    });

    // Admin Direct Income Aliases
    Route::get('/admin/direct-income/overview', [\App\Http\Controllers\Admin\AdminIncomeReportController::class, 'getDirectIncomeOverview']);
    Route::get('/admin/direct-income/orders', [\App\Http\Controllers\Admin\AdminIncomeReportController::class, 'getOrderDirectIncomeList']);
    Route::get('/admin/direct-income/orders/{orderId}', [\App\Http\Controllers\Admin\AdminIncomeReportController::class, 'getOrderDirectIncomeDetails']);
});






