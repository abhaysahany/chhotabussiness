<?php

namespace App\Http\Controllers;

use App\Models\SupportTicket;
use App\Models\SupportMessage;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class SupportTicketController extends Controller
{
    /**
     * Get tickets for current user from MySQL database
     */
    public function getUserTickets(Request $request)
    {
        $user = auth('sanctum')->user() ?: $request->user();
        if (!$user && $request->filled('user_code')) {
            $user = User::where('user_code', $request->input('user_code'))->first();
        }
        if (!$user && $request->filled('user_id')) {
            $user = User::find($request->input('user_id'));
        }

        $query = SupportTicket::with(['messages' => function ($q) {
            $q->orderBy('created_at', 'asc');
        }]);

        if ($user) {
            $query->where(function ($q) use ($user) {
                $q->where('user_id', $user->id)
                  ->orWhere('user_email', $user->email)
                  ->orWhere('user_name', $user->name);
            });
        }

        if ($request->filled('status') && $request->input('status') !== 'All') {
            $query->where('status', $request->input('status'));
        }

        if ($request->filled('category') && $request->input('category') !== 'All') {
            $query->where('category', $request->input('category'));
        }

        if ($request->filled('search')) {
            $s = $request->input('search');
            $query->where(function ($q) use ($s) {
                $q->where('subject', 'like', "%{$s}%")
                  ->orWhere('ticket_code', 'like', "%{$s}%")
                  ->orWhere('category', 'like', "%{$s}%");
            });
        }

        $tickets = $query->orderBy('updated_at', 'desc')->get();

        return response()->json([
            'status' => 'success',
            'tickets' => $tickets,
        ]);
    }

    /**
     * Create a new support ticket in database
     */
    public function createTicket(Request $request)
    {
        $user = auth('sanctum')->user() ?: $request->user();
        if (!$user && $request->filled('user_code')) {
            $user = User::where('user_code', $request->input('user_code'))->first();
        }
        if (!$user && $request->filled('user_id')) {
            $user = User::find($request->input('user_id'));
        }

        $validator = Validator::make($request->all(), [
            'subject' => 'required|string|max:255',
            'category' => 'required|string|max:100',
            'priority' => 'nullable|in:Low,Medium,High,Urgent',
            'description' => 'required|string|min:5',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => $validator->errors()->first(),
            ], 422);
        }

        $customCategory = $request->input('custom_category');
        $category = $request->input('category');
        if ($category === 'Others' && !empty($customCategory)) {
            $category = "Others: " . trim($customCategory);
        }

        $userId = $user ? $user->id : 1;
        $userName = $user ? $user->name : ($request->input('user_name') ?: 'Registered Member');
        $userEmail = $user ? $user->email : ($request->input('user_email') ?: 'member@vyaparadnet.com');

        DB::beginTransaction();
        try {
            $nextId = (SupportTicket::max('id') ?? 0) + 101;
            $ticketCode = 'TK-' . date('Y') . '-' . str_pad($nextId, 4, '0', STR_PAD_LEFT);

            $ticket = SupportTicket::create([
                'ticket_code' => $ticketCode,
                'user_id' => $userId,
                'user_name' => $userName,
                'user_email' => $userEmail,
                'subject' => trim($request->input('subject')),
                'category' => $category,
                'priority' => $request->input('priority') ?: 'Medium',
                'status' => 'Open',
            ]);

            SupportMessage::create([
                'ticket_id' => $ticket->id,
                'sender_type' => 'user',
                'sender_name' => $userName,
                'message' => trim($request->input('description')),
                'attachment' => $request->input('attachment') ?: null,
            ]);

            DB::commit();

            $freshTicket = SupportTicket::with('messages')->find($ticket->id);

            return response()->json([
                'status' => 'success',
                'message' => "✓ Support ticket {$ticketCode} created successfully in database!",
                'ticket' => $freshTicket,
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            \Illuminate\Support\Facades\Log::error('Failed to create support ticket: ' . $e->getMessage(), ['trace' => $e->getTraceAsString()]);
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to create support ticket. Please try again shortly.',
            ], 500);
        }
    }

    /**
     * User / Admin Reply to an existing ticket
     */
    public function replyTicket(Request $request, $id)
    {
        $ticket = SupportTicket::find($id);
        if (!$ticket) {
            return response()->json(['status' => 'error', 'message' => 'Support ticket not found.'], 404);
        }

        $validator = Validator::make($request->all(), [
            'message' => 'required|string|min:2',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 'error', 'message' => $validator->errors()->first()], 422);
        }

        $user = auth('sanctum')->user() ?: $request->user();
        $senderType = $request->input('sender_type') ?: ($user ? 'user' : 'user');
        $senderName = $request->input('sender_name') ?: ($user ? $user->name : 'Member');

        $message = SupportMessage::create([
            'ticket_id' => $ticket->id,
            'sender_type' => $senderType,
            'sender_name' => $senderName,
            'message' => trim($request->input('message')),
            'attachment' => $request->input('attachment') ?: null,
        ]);

        if ($senderType === 'admin') {
            $ticket->status = 'In Progress';
        } elseif ($ticket->status === 'Resolved' || $ticket->status === 'Closed') {
            $ticket->status = 'Open';
        }
        $ticket->touch();

        $freshTicket = SupportTicket::with('messages')->find($ticket->id);

        return response()->json([
            'status' => 'success',
            'message' => '✓ Message posted successfully!',
            'ticket' => $freshTicket,
        ]);
    }

    /**
     * Update ticket status (Resolve / Close)
     */
    public function updateStatus(Request $request, $id)
    {
        $ticket = SupportTicket::find($id);
        if (!$ticket) {
            return response()->json(['status' => 'error', 'message' => 'Ticket not found.'], 404);
        }

        $status = $request->input('status');
        if (!in_array($status, ['Open', 'In Progress', 'Resolved', 'Closed'])) {
            return response()->json(['status' => 'error', 'message' => 'Invalid status value.'], 422);
        }

        $ticket->status = $status;
        $ticket->save();

        $freshTicket = SupportTicket::with('messages')->find($ticket->id);

        return response()->json([
            'status' => 'success',
            'message' => "✓ Ticket {$ticket->ticket_code} status updated to {$status}!",
            'ticket' => $freshTicket,
        ]);
    }

    /**
     * Admin: List all tickets in system
     */
    public function getAdminTickets(Request $request)
    {
        $query = SupportTicket::with(['messages' => function ($q) {
            $q->orderBy('created_at', 'asc');
        }]);

        if ($request->filled('status') && $request->input('status') !== 'All') {
            $query->where('status', $request->input('status'));
        }

        if ($request->filled('category') && $request->input('category') !== 'All') {
            $query->where('category', $request->input('category'));
        }

        if ($request->filled('search')) {
            $s = $request->input('search');
            $query->where(function ($q) use ($s) {
                $q->where('subject', 'like', "%{$s}%")
                  ->orWhere('ticket_code', 'like', "%{$s}%")
                  ->orWhere('user_name', 'like', "%{$s}%")
                  ->orWhere('user_email', 'like', "%{$s}%");
            });
        }

        $tickets = $query->orderBy('updated_at', 'desc')->get();

        return response()->json([
            'status' => 'success',
            'tickets' => $tickets,
        ]);
    }
}
